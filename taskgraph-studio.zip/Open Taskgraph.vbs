Option Explicit
Dim shell, fs, folder, python, candidate
Set shell = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
folder = fs.GetParentFolderName(WScript.ScriptFullName)
python = shell.ExpandEnvironmentStrings("%USERPROFILE%") & "\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\pythonw.exe"
If Not fs.FileExists(python) Then
    python = ""
    Dim root, subfolder
    root = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python"
    If fs.FolderExists(root) Then
        For Each subfolder In fs.GetFolder(root).SubFolders
            candidate = subfolder.Path & "\pythonw.exe"
            If fs.FileExists(candidate) Then python = candidate
        Next
    End If
End If
If python = "" Or Not fs.FileExists(python) Then
    MsgBox "Python could not be found. Install Python 3.11 or newer, then reopen Taskgraph.", 48, "Taskgraph Studio"
Else
    shell.CurrentDirectory = folder
    shell.Run Chr(34) & python & Chr(34) & " " & Chr(34) & folder & "\desktop.py" & Chr(34), 0, False
End If
